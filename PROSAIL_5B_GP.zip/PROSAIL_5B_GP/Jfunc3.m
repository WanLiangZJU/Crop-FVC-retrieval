function out=Jfunc3(k,l,t)
out=(1.-exp(-(k+l)*t))/(k+l);
