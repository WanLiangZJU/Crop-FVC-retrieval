function freqvar=calc_LIDF_ellipsoidal(alpha)

alphadeg=alpha;
freq=campbell(alphadeg);
freqvar=freq;
